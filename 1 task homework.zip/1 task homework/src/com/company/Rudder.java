package com.company;

public enum Rudder {
    LEFT_HAND_DRIVE, RIGHT_HAND_DRIVE
}
